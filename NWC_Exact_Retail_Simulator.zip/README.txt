NWC Workplace Simulator — exact visual-reference prototype
One department: Retail Operations / Store Staff
One situation: A customer has a concern

The uploaded scenario image is used unchanged as the visual master.
Transparent interactive hotspots are layered over the decision options and Learning Assistant.
The Learning Assistant supports customer perspective, community context, consequences, and typed questions.
